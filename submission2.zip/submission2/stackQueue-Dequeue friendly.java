import java.util.LinkedList;
import java.util.Queue;

class StackQueueDequeueFriendly {
    Queue<Integer> q = new LinkedList<>();

    // Push operation (costly)
    void push(int x) {
        int size = q.size();
        q.add(x);

        // Rotate elements
        for (int i = 0; i < size; i++) {
            q.add(q.remove());
        }
    }

    // Pop operation (O(1))
    int pop() {
        if (q.isEmpty()) {
            System.out.println("Stack is empty");
            return -1;
        }
        return q.remove();
    }

    int peek() {
        return q.peek();
    }

    boolean isEmpty() {
        return q.isEmpty();
    }
}
