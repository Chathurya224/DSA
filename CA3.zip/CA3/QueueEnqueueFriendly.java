public class QueueEnqueueFriendly {
    private int[] queue;
    private int front, rear, size;

    public QueueEnqueueFriendly(int capacity) {
        queue = new int[capacity];
        front = 0;
        rear = -1;
        size = 0;
    }

    public void enqueue(int value) {
        rear = (rear + 1) % queue.length;
        queue[rear] = value;
        size++;
        System.out.println("Enqueued: " + value);
    }

    public int dequeue() {
        int value = queue[front];
        front = (front + 1) % queue.length;
        size--;
        return value;
    }

    public static void main(String[] args) {
        QueueEnqueueFriendly q = new QueueEnqueueFriendly(5);
        q.enqueue(10);
        q.enqueue(20);
        System.out.println("Dequeued: " + q.dequeue());
    }
}
