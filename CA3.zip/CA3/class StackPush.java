class StackPush {
    int top = -1;
    int size = 5;
    int[] stack = new int[size];

    // PUSH operation
    void push(int value) {
        if (top == size - 1) {
            System.out.println("Stack is full. Cannot push.");
        } else {
            top++;
            stack[top] = value;
            System.out.println("Pushed element: " + value);
        }
    }
}
