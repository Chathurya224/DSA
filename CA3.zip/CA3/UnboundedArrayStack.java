public class UnboundedArrayStack {
    private int[] stack;
    private int top;

    public UnboundedArrayStack() {
        stack = new int[2];
        top = -1;
    }

    public void push(int value) {
        if (top == stack.length - 1) {
            resize(stack.length * 2);
        }
        stack[++top] = value;
        System.out.println("Pushed: " + value);
    }

    public int pop() {
        int value = stack[top--];

        if (top > 0 && top == stack.length / 4) {
            resize(stack.length / 2);
        }
        return value;
    }

    private void resize(int newSize) {
        int[] newStack = new int[newSize];
        for (int i = 0; i <= top; i++) {
            newStack[i] = stack[i];
        }
        stack = newStack;
    }

    public static void main(String[] args) {
        UnboundedArrayStack s = new UnboundedArrayStack();
        s.push(10);
        s.push(20);
        s.push(30);
        System.out.println("Popped: " + s.pop());
        System.out.println("Popped: " + s.pop());
    }
}
