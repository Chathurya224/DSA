class StackPop {
    int top = -1;
    int size = 5;
    int[] stack = new int[size];

    // POP operation
    void pop() {
        if (top == -1) {
            System.out.println("Stack is empty. Cannot pop.");
        } else {
            System.out.println("Popped element: " + stack[top]);
            top--;
        }
    }
}
