public class StackPushFriendly {
    private int[] stack;
    private int top;

    public StackPushFriendly(int size) {
        stack = new int[size];
        top = -1;
    }

    public void push(int value) {
        stack[++top] = value;
        System.out.println("Pushed: " + value);
    }

    public int pop() {
        return stack[top--];
    }

    public static void main(String[] args) {
        StackPushFriendly s = new StackPushFriendly(5);
        s.push(10);
        s.push(20);
        System.out.println("Popped: " + s.pop());
    }
}
